const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Mock data
let users = [];
let adminCredentials = null;

// Routes
app.get('/', (req, res) => {
    if (!adminCredentials) return res.redirect('/register');
    res.redirect('/login');
});

app.get('/register', (req, res) => {
    if (adminCredentials) return res.redirect('/login');
    res.render('register');
});

app.post('/register', (req, res) => {
    const { username, password } = req.body;
    adminCredentials = { username, password };
    res.redirect('/login');
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (adminCredentials && username === adminCredentials.username && password === adminCredentials.password) {
        req.session.loggedIn = true;
        res.redirect('/dashboard');
    } else {
        res.send('Invalid credentials <a href="/login">Try again</a>');
    }
});

app.get('/dashboard', (req, res) => {
    if (!req.session.loggedIn) return res.redirect('/login');
    res.render('dashboard', { users });
});

app.post('/add-user', (req, res) => {
    if (!req.session.loggedIn) return res.redirect('/login');
    const { name, email, phone } = req.body;
    users.push({ name, email, phone });
    res.redirect('/dashboard');
});

app.post('/delete-user', (req, res) => {
    if (!req.session.loggedIn) return res.redirect('/login');
    users.splice(req.body.index, 1);
    res.redirect('/dashboard');
});

app.post('/modify-user', (req, res) => {
    if (!req.session.loggedIn) return res.redirect('/login');
    const { index, name, email, phone } = req.body;
    users[index] = { name, email, phone };
    res.redirect('/dashboard');
});

app.post('/search-user', (req, res) => {
    if (!req.session.loggedIn) return res.redirect('/login');
    const keyword = req.body.keyword.toLowerCase();
    const filtered = users.filter(u => u.name.toLowerCase().includes(keyword) || u.email.toLowerCase().includes(keyword));
    res.render('dashboard', { users: filtered });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

app.get('/edit-user/:index', (req, res) => {
    if (!req.session.loggedIn) return res.redirect('/login');
    const index = req.params.index;
    res.render('edit-user', { index, user: users[index] });
});

app.post('/edit-user/:index', (req, res) => {
    if (!req.session.loggedIn) return res.redirect('/login');
    const index = req.params.index;
    const { name, email, phone } = req.body;
    users[index] = { name, email, phone };
    res.redirect('/dashboard');
});

app.get('/delete-user/:index', (req, res) => {
    if (!req.session.loggedIn) return res.redirect('/login');
    const index = req.params.index;
    res.render('delete-user', { index, user: users[index] });
});

app.post('/delete-user/:index', (req, res) => {
    if (!req.session.loggedIn) return res.redirect('/login');
    const index = req.params.index;
    users.splice(index, 1);
    res.redirect('/dashboard');
});